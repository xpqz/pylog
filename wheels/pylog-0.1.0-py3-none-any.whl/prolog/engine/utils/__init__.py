"""Utility modules for the Prolog engine."""
